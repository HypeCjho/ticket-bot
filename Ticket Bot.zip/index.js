
/*

    This project is open-source and can be used for anyone.
    I would also appreciate it if you would like to credit me.

    ADS:

    Buy bots from me: Hyp3r#0001
    Cheap Hosting: https://shardhost.xyz
    Pokemom Bot: https://invite.pikacord.xyz

    CREDIT:

    Made by Hyp3r#0001

    HOW TO:

    Generate ticket embed by typing "<prefix>start"
    Bot will then send an embed that will check for reaction
    and make a new ticket when a reaction has been added

*/

const { MessageEmbed, MessageAttachment } = require("discord.js");
const { Collection, Client, Discord } = require("discord.js");
const fs = require("fs");
const bot = new Client({
  disableEveryone: true
});

const config = require("./config.json");

bot.commands = new Collection();
bot.aliases = new Collection();
bot.prefix = config.prefix;
bot.staffID = config.serverConfig.staffRole;

bot.on("ready", async () => {
    const status = `Ticket Bot`;
    bot.user.setActivity(status, { type: "WATCHING" });
    console.log(`Logged in as ${bot.user.tag}`)  
});

bot.on("message", async message => {
    let prefix = config.prefix;
    String.prototype.capitalize = function() {
        let words = this.split(/ +/g)
        let finalWord = [];
        for(let word of words) {
            finalWord.push(`${word[0]}${word.slice(1).join(" ")}`)
        }
        return finalWord;
    }
    if (message.author.bot) return;
    if(message.content.toLowerCase() === `${prefix}start`) {
        let embed = new MessageEmbed()
        .setTitle("Create A New Ticket")
        .addField("Support Ticket", "**React with ✉️ to create a new ticket**")
        .setColor("GREEN")
        .setFooter("Support Ticket")
        let m = await message.channel.send(embed)
        m.react("✉️")
        const reactionCollector = m.createReactionCollector((reaction, user) => reaction.emoji.name === '✉️' && !user.bot)
        reactionCollector.on('collect', async (reaction, user) => {
            reaction.users.remove(user.id)
            let channel = await message.guild.channels.create(`${message.author.username}-${message.author.discriminator}`, {permissionOverwrites: [
                {
                    id: user.id,
                    allow: ["VIEW_CHANNEL"]
                },
                {
                    id: bot.staffID,
                    allow: ["VIEW_CHANNEL"]
                },
                {
                    id: message.guild.roles.everyone.id,
                    deny: ["VIEW_CHANNEL"]
                }
            ]})
            let newTicket = new MessageEmbed()
            .setTitle("New Ticket")
            .setDescription("Thanks for creating a new Ticket. Please wait patiently while we're trying to contact staff.")
            .setFooter("Ticket Bot")
            .setColor("GREEN")
            .setFooter("📝 - Generate Transcript ・ ❌ - Close Ticket")
            const options = await channel.send(newTicket)
            options.react("📝")
            options.react("❌")
            const con = await options.createReactionCollector((reaction, user) => !user.bot)
            con.on('collect', async (reaction, user2) => {
                switch(reaction.emoji.name) {
                    case "❌": {
                        let noteEmbed = new MessageEmbed()
                        .setTitle("Ticket Closed")
                        .setDescription(`Your support ticket in **${message.guild.name}** has been closed`)
                        .setFooter("Ticket Bot")
                        .setColor("RED")
                        user.send(noteEmbed)
                        channel.delete();
                        break;
                    }
                    case "📝": {
                        let transcript = new MessageEmbed()
                        .setDescription("**Generating transcript. Please wait...**")
                        .setColor("GREEN")
                        channel.send(transcript);
                        setTimeout(async () => {
                            const allMessages = channel.messages.cache.filter(m => !m.author.bot).map(m => `[${user.id === user2.id ? "Member" : "Staff"}] ${message.author.username}-${message.author.discriminator} : ${m.content}`)
                            await fs.writeFileSync('./ticket-log.txt', allMessages.join("\n"))
                            channel.send("**MAKE SURE TO DOWNLOAD THIS FILE BEFORE CLOSING THE TICKET**", new MessageAttachment(fs.createReadStream('./ticket-log.txt'), `${user.username}-${user.discriminator}`))
                        }, 3000)
                    }
                }
            })
        })
    }
});

bot.login(config.token);
